# Daily Task Helper

Simple useful daily helper.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
-m pip install <PyPI project url>
```

## Usage

Open cmd.exe and type next command to run the script:

```bash
daily-task-helper
```
## License

[MIT](https://choosealicense.com/licenses/mit/)
